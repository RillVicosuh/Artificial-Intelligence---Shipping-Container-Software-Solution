# AI-Migos Software - Shipping Container Problem
## Project Description
This is a senior design project under the instruction of [Dr.Eamonn Keogh](https://www.cs.ucr.edu/~eamonn/) for the Winter 2023 Quarter at UCR. Here we are tasked with designing and implementing a software based solution to a shipping container problem. 

## Developers
* [Brandon Chea](https://github.com/Bchea99)
* [Anand Mahadevan](https://github.com/AnandMaha)
* [David Tellez](https://github.com/Davtellez01)
* [Ricardo Villacana](https://github.com/RillVicosuh)

